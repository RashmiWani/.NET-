﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel.DataAnnotations;

namespace ORM_LINQ_Cuatomer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        Sep19CHNEntities1 contextObj = new Sep19CHNEntities1();
        private void btn_display_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                //if (txt_emplocation.Text != string.Empty)
                //{

                var query = from Customer cst in contextObj.Customers       //DATA SOURCE
                        select cst;

            List<Customer> cstlist = new List<Customer>();
            cstlist = query.ToList<Customer>();

            if (cstlist.Count <= 0)
                MessageBox.Show("No Records found");
            else
            {
                dg_customer.ItemsSource = query.ToList();
            }
                //}
                //else
                //{ MessageBox.Show("Please Enter Location !"); }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Customer custToBeDeleted; //= new Employee();

                int custID = Convert.ToInt32(txt_delete.Text);
                custToBeDeleted = contextObj.Customers.FirstOrDefault(cst => cst.cust_id == custID);

                if (custToBeDeleted != null)
                {
                    contextObj.Customers.Remove(custToBeDeleted);    // delete operation
                    contextObj.SaveChanges();                       //Save changes to database
                    MessageBox.Show("Customer Details deleted");

                }
                else throw new Exception("Delete could not be done !");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
