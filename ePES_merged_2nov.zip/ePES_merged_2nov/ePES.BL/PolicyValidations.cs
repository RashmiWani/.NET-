﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using ePES.Entity;
using ePES.Exceptions;
using ePES.DAL;

namespace ePES.BL
{
    public class PolicyValidations
    {

        // Validations for login credentials
        public bool ValidateLoginCredentials(LoginCredentials log)
        {
            bool isValidUser = true;
            StringBuilder Message = new StringBuilder();
            try
            {
                //Checking LoginID
                if (log.loginID == string.Empty)
                {
                    Message.Append("LoginID should be provided\n");
                    isValidUser = false;
                }
                //Checking User Password
                if (log.userpassword == string.Empty)
                {
                    Message.Append("User Password should be provided\n");
                    isValidUser = false;
                }
                //Checking User Type
                if (log.userType == string.Empty)
                {
                    Message.Append("Must Select User Type from dropdown");
                    isValidUser = false;
                }
                if (isValidUser == false)
                {
                    throw new PolicyExceptions(Message.ToString());
                }
            }
            catch (PolicyExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isValidUser;
        }

        //Final call to DAL--login
        public bool ValidateLogin(LoginCredentials log)
        {
            bool isvalid = false;
            try
            {
                PolicyValidations polval = new PolicyValidations();
                if (polval.ValidateLoginCredentials(log) == true) // funvtion of BLL
                {
                    PolicyOperations policyoperations = new PolicyOperations();  // control flow to call DAL
                    isvalid = policyoperations.ValidateUser(log);
                }
            }
            catch (PolicyExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return isvalid;
        }

        public static bool ValidateEndorsementsTemp(EndorsementsTemp temp)
        {
            bool isValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                //Checking Customer name
                if (temp.customerName == string.Empty)
                {
                    message.Append("Customer Name should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(temp.customerName, "[A-Z][a-z]{1,}"))
                {
                    message.Append("Customer Name should start with Capital Alphabet\n");
                    isValidated = false;
                }

                //Checking Customer Date Of Birth
                if (temp.customerDOB > DateTime.Now)
                {
                    message.Append("Date Of Birth should be less than or equal to Today's date\n");
                    isValidated = false;
                }

                //Checking Customer Gender
                //if(temp.customerGender == )


                //Checking Nominee Name
                if (temp.nomineeName == string.Empty)
                {
                    message.Append("Nominee Name should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(temp.nomineeName, "[A-Z][a-z]"))
                {
                    message.Append("Nominee Name should start with Capital Alphabet\n");
                    isValidated = false;
                }

                //Checking Nominee Relation
                if (temp.nomineeRelation == string.Empty)
                {
                    message.Append("Nominee Relation should be provided\n");
                    isValidated = false;
                }

                ////Checking if Customer is Smoker or Non-Smoker
                //if (temp.customerSmoking.ToLower() != "Smoker" && temp.customerSmoking.ToLower() != "Non-Smoker")
                //{
                //    message.Append("Customer should be either Smoker or Non-Smoker\n");
                //    isValidated = false;
                //}

                //Checking Customer Address
                if (temp.customerAddress == string.Empty)
                {
                    message.Append("Customer Address should be provided\n");
                    isValidated = false;
                }

                //Checking Telephone Number
                if (!Regex.IsMatch(temp.customerTelephone, "[7-9][0-9]{9}"))
                {
                    message.Append("Telephone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    isValidated = false;
                }

                //Checking Premiun Payment Frequency
                //if (temp.premiumFrequency.ToUpper() != "Monthly" && temp.premiumFrequency.ToLower() != "Quaterly" && temp.premiumFrequency.ToLower() != "Half Yearly" && temp.premiumFrequency.ToLower() != "Annually")
                //{
                //    message.Append("Premium  Frequency should be either Monthly or Quaterly or Half Yearly or Annually\n");
                //    isValidated = false;
                //}

                if (isValidated == false)
                    throw new PolicyExceptions(message.ToString());
            }
            catch (PolicyExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isValidated;
        }


        //--------------------------------------------------------------------


        public static bool ValidateCustomer(int PN, int custID, DateTime custDob, string cname)  // customer class validation
        {
            bool isValidCustomer = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (cname.ToString() ==null)   // for customer name
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Customer Name \n");
                }
                 if (!Regex.IsMatch(cname, "[A-Z][a-z]+"))
                {
                    isValidCustomer = false;
                    sbError.Append("Customer Name should start with Capital Alphabet, it should contain only alphabets \n");

                }

                 if (custID== 0)  // for customer ID
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Customer ID \n");
                }

                 if (custDob == DateTime.MinValue)   // for Date of Birth    Convert.ToDateTime("01/01/1001")
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Customer Date of Birth \n");
                }
                 if (custDob > DateTime.Now)
                {
                    isValidCustomer = false;
                    sbError.Append("Date of Birth should be less than present date \n");
                }
                //else if(!Regex. IsMatch(custDob.ToString(), "mm/dd/yyyy"))
                //{
                //    sbError.Append("Customer Date of Birth should be in proper date format-- mm/dd/yyyy \n");
                //    isValidCustomer = false;
                //}
                if (PN == 0)  // for policy number
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Policy Number \n");
                }
                 if (PN > 25 || PN < 11 || (PN > 15 && PN < 21))
                {
                    isValidCustomer = false;
                    sbError.Append("Please enter Policy Number between 11 to 15 or 21 to 25 \n");
                }
                if (isValidCustomer == false)
                    throw new PolicyExceptions(sbError.ToString());
            }
            catch (PolicyExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return isValidCustomer;
        }

        static DataTable dtCust;
        public static DataTable GetPolicy_BLL(int custID, DateTime DOB, int PN, string Name)  // for search
        {

            try
            {
                if (ValidateCustomer(PN, custID, DOB, Name))
                {

                    PolicyOperations poloperations = new PolicyOperations();
                    dtCust = PolicyOperations.GetPolicy_DAL(custID, DOB, PN, Name);
                }

            }

            catch (SqlException ex)
            {

                throw ex;
            }
            catch (PolicyExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtCust;

        }


        //---------------------------------------------


        PolicyOperations plcOperation;

        public DataTable GetEndoPermanent_BL(int cid,int pn)
        {
            DataTable dtEmp;
            try
            {
                plcOperation = new PolicyOperations();

                dtEmp = plcOperation.GetEndoPermanent_DAL(cid,pn);

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {


            }
            return dtEmp;

        }
    }
}
