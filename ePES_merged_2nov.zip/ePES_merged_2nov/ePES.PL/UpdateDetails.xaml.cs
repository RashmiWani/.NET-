﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;

using System.Data;
using System.Data.SqlClient;


namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for UpdateDetails.xaml
    /// </summary>
    public partial class UpdateDetails : Window
    {
        public UpdateDetails()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cbPremiumPaymentFrequency.Items.Add("MONTHLY");
            cbPremiumPaymentFrequency.Items.Add("QUATERLY");
            cbPremiumPaymentFrequency.Items.Add("HALF-YEARLY");
            cbPremiumPaymentFrequency.Items.Add("ANNUALLY");
            //------------------------------------------------------------------

            MainWindow mw = new MainWindow();
            // int empid = Convert.ToInt32(mw.txt_ID_Search.Text);

            int id = Convert.ToInt32( txtID.Text);
            int pn = Convert.ToInt32(txtPolicyNumber.Text);
            PolicyValidations validationObj1 = new PolicyValidations();
            DataTable sEd = validationObj1.GetEndoPermanent_BL(id,pn);

            DataRow dr = sEd.Rows[0];

            if ((!dr.IsNull("customerID")) && (!dr.IsNull("policyNumber")))
            {
                txtTransactionID.Text = dr["transactionID"].ToString();

                txtPolicyName.Text = dr["policyName"].ToString();

                txtProductLine.Text = dr["productLine"].ToString();

                txtInsuredName.Text = dr["customerName"].ToString();

                txtAddress.Text = dr["customerAddress"].ToString();

                txtTelephone.Text = dr["customerTelephone"].ToString();

                txtNomineeName.Text = dr["nomineeName"].ToString();

                txtNomineeRelation.Text = dr["nomineeRelation"].ToString();
            }
            //else
            //    MessageBox.Show("No Records found with Emp Id : " + empid);


        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

            EndorsementsTemp newEsm = new EndorsementsTemp();

            newEsm.transactionID = Convert.ToInt32(txtTransactionID.Text);

            newEsm.policyNumber = Convert.ToInt32(txtPolicyNumber.Text);

            newEsm.policyName = txtPolicyName.Text;

            newEsm.productLine = txtProductLine.Text;

            newEsm.customerName = txtInsuredName.Text;

            newEsm.customerDOB = Convert.ToDateTime(txtDOB.Text);

            if (rbFemale.IsChecked == true)
                newEsm.customerGender = rbFemale.Content.ToString();
            else if (rbMale.IsChecked == true)
                newEsm.customerGender = rbMale.Content.ToString();

            newEsm.nomineeName = txtNomineeName.Text;

            newEsm.nomineeRelation = txtNomineeRelation.Text;

            if (rbNonSmoker.IsChecked == true)
                newEsm.customerSmoking = rbNonSmoker.Content.ToString();
            else if (rbSmoker.IsChecked == true)
                newEsm.customerSmoking = rbSmoker.Content.ToString();

            newEsm.customerAddress = txtAddress.Text;

            newEsm.customerTelephone = txtTelephone.Text;

            newEsm.premiumFrequency = cbPremiumPaymentFrequency.SelectedValue.ToString();

        }

    }
}
