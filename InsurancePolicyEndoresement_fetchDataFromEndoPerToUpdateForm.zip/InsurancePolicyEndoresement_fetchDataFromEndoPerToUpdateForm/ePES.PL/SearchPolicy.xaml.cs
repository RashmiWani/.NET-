﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;

namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for SearchPolicy.xaml
    /// </summary>
    public partial class SearchPolicy : Window
    {
        public SearchPolicy()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtCustomerID.Clear();
            txtCustomerName.Clear();
            txtDOB.Clear();
            //dtpicker.ClearValue();
            txtPolicyNumber.Clear();
            //dgPolicy.ClearValue(;  // clear data grid 
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //  PolicyValidations bllObj = new PolicyValidations();
                int c_id = int.Parse(txtCustomerID.Text);
                DateTime c_dob = Convert.ToDateTime(txtDOB.Text);
                int c_pn = Convert.ToInt32(txtPolicyNumber.Text);
                string c_name = txtCustomerName.Text;

                DataTable dtEmp = PolicyValidations.GetPolicy_BLL(c_id, c_dob, c_pn, c_name);
                dgPolicy.ItemsSource = dtEmp.DefaultView;


            }
            catch (PolicyExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }


        private void btnViewDetails_Click(object sender, RoutedEventArgs e)
        {
            UpdateDetails ud = new UpdateDetails();
            ud.txtID.Text = txtCustomerID.Text;
            ud.txtPolicyNumber.Text = txtPolicyNumber.Text;

            ud.Show(); 
        }
    }
}
