create table Manish.NSStateAgent
(
FlatID int identity(100,1) primary key, 
FirstName varchar(20),
LastName varchar(20),
MoNo bigint,
Flat_type varchar(20),
Flat_Area float(10),
RentAmt bigint,
DepositAmt bigint
)

create proc Manish.usp_AddFlatDetails
@FirstName varchar(20),
@LastName varchar(20),
@MoNo bigint,
@Flat_type varchar(20),
@Flat_Area float(10),
@RentAmt bigint,
@DepositAmt bigint
as
BEGIN
insert into Manish.NSStateAgent values(@FirstName,
@LastName,
@MoNo,
@Flat_type,
@Flat_Area,
@RentAmt,
@DepositAmt)
End

select * from Manish.NSStateAgent


Exec  Manish.usp_AddFlatDetails 'Manish','Rahangdale',7769942667,'1-BHK',2500,1500,3000

create table Manish.FlatType
(
FtypeId int primary key,
FtypeName varchar(30),

)


 create proc Manish.usp_DisplayFtype
 AS
 BEGIN
 select * from Manish.FlatType
 END
 
 insert into Manish.FlatType values(1,'1-BHK')
  insert into Manish.FlatType values(2,'2-BHK')
   insert into Manish.FlatType values(3,'3-BHK')

 Exec  Manish.usp_DisplayFtype
 