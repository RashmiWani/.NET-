﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using NSS_Entity;
using NSS_Exception;

namespace NSS_DAL
{
    /// <summary>
    /// Employee ID : 161611
    /// Employee Name : Manish Rahangdale
    /// Descrition : This Class Actual operation methods for operation on data and have direct access to database
    /// Date of Modification : 17th Oct 2018
    /// </summary>

    public class FlatOperation
    {
        static string flatConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection flatConnObj;
        SqlCommand flatCommand;
        DataTable dtFlat;
        SqlDataReader flatReader = null;

        public FlatOperation()
        {
            flatConnObj = new SqlConnection();
            flatConnObj.ConnectionString = flatConnStr;
        }


        //Method to load Flat type from Database and return it to BLL 
        public DataTable LoadFlatType()
        {

            try
            {
                dtFlat = new DataTable();
                flatCommand = new SqlCommand("Manish.usp_DisplayFtype", flatConnObj);
                flatCommand.CommandType = CommandType.StoredProcedure;
                flatConnObj.Open();
                flatReader = flatCommand.ExecuteReader();
                dtFlat.Load(flatReader);

            }
            catch (SqlException)
            {
                throw;

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                flatReader.Close();
                if (flatConnObj.State == ConnectionState.Open) flatConnObj.Close();
            }
            return dtFlat;
        }


        //Method to Add Flat Details into Database  
        public int AddFlatDetails_DAL(FlatDetails flat)
        {
            int rowsAffected = 0;
            try
            {


                flatCommand = new SqlCommand("Manish.usp_AddFlatDetails", flatConnObj);
                flatCommand.CommandType = CommandType.StoredProcedure;
                flatCommand.Parameters.AddWithValue("@FirstName", flat.FirstName);
                flatCommand.Parameters.AddWithValue("@LastName", flat.LastName);
                flatCommand.Parameters.AddWithValue("@MoNo", flat.MoNo);
                flatCommand.Parameters.AddWithValue("@Flat_type", flat.Flat_type);
                flatCommand.Parameters.AddWithValue("@Flat_Area", flat.Flat_Area);
                flatCommand.Parameters.AddWithValue("@RentAmt", flat.RentAmt);
                flatCommand.Parameters.AddWithValue("@DepositAmt", flat.DepositAmt);
                flatConnObj.Open();
                rowsAffected = flatCommand.ExecuteNonQuery();
            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (flatConnObj.State == ConnectionState.Open) flatConnObj.Close();
            }
            return rowsAffected;
        }


        }
    }
