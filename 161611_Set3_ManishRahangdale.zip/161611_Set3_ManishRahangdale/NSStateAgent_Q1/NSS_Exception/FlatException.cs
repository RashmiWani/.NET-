﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSS_Exception
{
    /// <summary>
    /// Employee ID : 161611
    /// Employee Name : Manish Rahangdale
    /// Descrition : This class defines User Defined Exceptions
    /// Date of Modification : 17th Oct 2018
    /// </summary>

    public class FlatException : ApplicationException
    {


        public FlatException()
            : base()
        { }

        public FlatException(string Message) : base(Message)
        { }
    }
}
