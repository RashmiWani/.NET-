﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Employee ID : 161611
/// Employee Name : Manish Rahangdale
/// Descrition : This is an Flat details class for an NssAgent Project
/// Date of Modification : 17th Oct 2018
/// </summary>

namespace NSS_Entity
{
    public class FlatDetails
    {
        public int FlatID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public long MoNo { get; set; }

        public string Flat_type { get; set; }

        public float Flat_Area { get; set; }

        public long RentAmt { get; set; }

        public long DepositAmt { get; set; }

    }
}
