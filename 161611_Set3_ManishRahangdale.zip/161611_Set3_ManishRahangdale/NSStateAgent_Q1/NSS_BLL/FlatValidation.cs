﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using NSS_Entity;
using NSS_Exception;
using NSS_DAL;
using System.Text.RegularExpressions;


namespace NSS_BLL
{

    /// <summary>
    /// Employee ID : 161611
    /// Employee Name : Manish Rahangdale
    /// Descrition : This Class Define Bussiness Logic for operation on data
    /// Date of Modification : 17th Oct 2018
    /// </summary>


    public class FlatValidation
    {
        //method to Load Flat type from the FlatType table
        public DataTable LoadFlatType_BLL()
        {
            DataTable dtFlat;
            try
            {
               FlatOperation flatOperation = new FlatOperation();
                dtFlat = flatOperation.LoadFlatType();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtFlat;
        }


        //method to validate user input according to Requirements, it calls actual operation method in DAL
        public bool validateFlat(FlatDetails newFlat)
        {
            bool isValidFlat = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (newFlat.FirstName == string.Empty )
                {
                    isValidFlat = false;
                    sbError.Append("\n Please enter First Name");
                }
                else if (!Regex.IsMatch(newFlat.FirstName, "[A-Z][a-z]{2,}"))
                {
                    sbError.Append("First Name should start with Capital Alphabet and only alphabets\n");
                    isValidFlat = false;
                }


                if (newFlat.LastName == string.Empty)
                {
                    isValidFlat = false;
                    sbError.Append("\n Please enter Last Name");
                }
                else if (!Regex.IsMatch(newFlat.LastName, "[A-Z][a-z]{2,}"))
                {
                    sbError.Append("Last Name should start with Capital Alphabet and only alphabets\n");
                    isValidFlat = false;
                }


                if (newFlat.MoNo.ToString() == string.Empty)
                {
                    isValidFlat = false;
                    sbError.Append("\n Please enter Mobile Number");
                }
                //else if (!Regex.IsMatch(newFlat.LastName.ToString(), "[7-9][0-9]{9}"))
                //{
                //    sbError.Append("Phone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                //    isValidFlat = false;
                //}



                if (newFlat.Flat_Area.ToString() == string.Empty)
                {
                    isValidFlat = false;
                    sbError.Append("\n Please enter Flat Area");
                }
                else if (!Regex.IsMatch(newFlat.Flat_Area.ToString(), "[0-9]"))
                {
                    sbError.Append(" Flat Area should have digits only\n");
                    isValidFlat = false;
                }

                if (newFlat.RentAmt.ToString() == string.Empty)
                {
                    isValidFlat = false;
                    sbError.Append("\n Please enter Rent Amount");
                }
                else if (!Regex.IsMatch(newFlat.RentAmt.ToString(), "[0-9]"))
                {
                    sbError.Append(" Rent Amount should have digits only\n");
                    isValidFlat = false;
                }


                if (newFlat.DepositAmt.ToString() == string.Empty)
                {
                    isValidFlat = false;
                    sbError.Append("\n Please enter Deposit Amount");
                }
                else if (!Regex.IsMatch(newFlat.DepositAmt.ToString(), "[0-9]"))
                {
                    sbError.Append(" Deposit Amount should have digits only\n");
                    isValidFlat = false;
                }
                else if (newFlat.DepositAmt<newFlat.RentAmt)
                {
                    isValidFlat = false;
                    sbError.Append("\n Deposit Amount Should be greater than Rent Amount");
                }

                if (!isValidFlat)
                    throw new FlatException(sbError.ToString());
            }
            catch (FlatException ex)
            { throw ex; }

            return isValidFlat;
        }

        //method to add Employee details, it calls actual operation method in DAL
        public int AddFlatDetails_BLL(FlatDetails newFlat)
        {
            int rowsAffected = 0;
            FlatOperation operationObj;
             
            try
            {
                if (validateFlat(newFlat))
                {
                    operationObj = new FlatOperation();
                    rowsAffected = operationObj.AddFlatDetails_DAL(newFlat);
                }
            }
            catch (FlatException ex)
            { throw ex; }
            catch (SqlException se)
            { throw se; }
            catch (Exception ex)
            { throw ex; }

            return rowsAffected;

        }


    }
}
