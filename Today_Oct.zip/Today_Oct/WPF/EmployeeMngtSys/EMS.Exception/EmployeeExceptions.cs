﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exceptions
{
    public class EmployeeExceptions : ApplicationException
    {
        //Default Constructor
        public EmployeeExceptions() : base()
        { }

        //Parameterized constructor with message parameter
        public EmployeeExceptions(string message) : base(message)
        { }
    }
}
