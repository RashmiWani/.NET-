﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EMS.Entity;
using EMS.DAL;
using EMS.Exceptions;
using System.Configuration;

namespace EMS.BL
{
    public class EmployeeValidations
    {
        EmployeeOperations empOperation;
        public DataTable LoadDeparmentBLL()
        {
            DataTable dtDept;
            try
            {
                empOperation = new EmployeeOperations();
                dtDept = empOperation.LoadDeparment();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtDept;
        }

        public DataTable DisplayEmployeeBLL()
        {
            DataTable dtEmp;
            try
            {
                empOperation = new EmployeeOperations();
                dtEmp = empOperation.DisplayEmployeeDAL();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtEmp;
        }

        public bool validateEmp(Employee newEmp)
        {
            bool isValidEmp = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (newEmp.EmpName == string.Empty)
                {
                    isValidEmp = false;
                    sbError.Append("Pl enter Employee Name");
                }
                if (!isValidEmp) throw new EmployeeExceptions(sbError.ToString());
            }
            catch (EmployeeExceptions ex)
            { throw ex; }

            return isValidEmp;
        }

        public int AddEmployeeBLL(Employee newEmp)
        {
            int rowsAffected = 0;
            EmployeeOperations operationObj;
            try
            {
                if (validateEmp(newEmp))
                {
                    operationObj = new EmployeeOperations();
                    rowsAffected = operationObj.AddEmployeeDAL(newEmp);
                }
            }
            catch (EmployeeExceptions ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;

        }

        public bool DeleteEmployeeBLL(int empid)
        {
            
            try
            {
                empOperation = new EmployeeOperations();
                return empOperation.DeleteEmployeeDAL(empid);
            }
            catch (EmployeeExceptions ex)
            { throw ex; }

           
        }
    }
}
