﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EMS.Entity;
using EMS.Exceptions;
using System.Configuration;

namespace EMS.DAL
{
    public class EmployeeOperations
    {

        static string empConnStr = ConfigurationManager.ConnectionStrings["conString"].ToString();
        static SqlConnection empConnObj;
        SqlCommand empCommand;
        DataTable dtDept, dtEmp;
        SqlDataReader empReader = null;

        public EmployeeOperations()
        {
            empConnObj = new SqlConnection();
            empConnObj.ConnectionString = empConnStr;
        }
        // Load ComboBox
        //Insert Data
        // Display Data
        // Get Next Id - using O/P parameter

        public DataTable LoadDeparment()
        {

            try
            {
                dtDept = new DataTable();
                empCommand = new SqlCommand("Rashmi.usp_GetDepartment", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                dtDept.Load(empReader);

            }
            catch (SqlException)
            {
                throw;

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return dtDept;
        }

        public int AddEmployeeDAL(Employee emp)
        {
            int rowsAffected = 0;
            try
            {
                empCommand = new SqlCommand("Rashmi.usp_AddNewEmployee", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;//,@eLoc,@ePh,@eDeptId
                empCommand.Parameters.AddWithValue("@e_name", emp.EmpName);
                empCommand.Parameters.AddWithValue("@e_location", emp.EmpLocation);
                empCommand.Parameters.AddWithValue("@e_contact", emp.EmpPhone);
                empCommand.Parameters.AddWithValue("@dept_id", emp.DeptID);
                empConnObj.Open();
                rowsAffected = empCommand.ExecuteNonQuery();
            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return rowsAffected;

        }

        public DataTable DisplayEmployeeDAL()
        {
            try
            {
                dtEmp = new DataTable();
                empCommand = new SqlCommand("Rashmi.usp_DisplayEmployee3", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dtEmp.Load(empReader);
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception )
            {

                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return dtEmp;
        }

        public bool DeleteEmployeeDAL(int empid)
        {
            bool result = false;
            try
            {
                dtEmp = new DataTable();
                empCommand = new SqlCommand("Rashmi.usp_DeleteEmployee3", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
              
                empCommand.Parameters.AddWithValue("@e_id", empid);
                empConnObj.Open();
                int rowsAffected = empCommand.ExecuteNonQuery();
                if(rowsAffected==1)
                {
                    result = true;
                }
            }
            catch (SqlException )
            {

                throw;
            }
            catch (Exception )
            {

                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return result;
        }
    }
}
