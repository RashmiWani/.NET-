﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace BankApplication
{
    /// <summary>
    /// Interaction logic for DisplayEmployee.xaml
    /// </summary>
    public partial class DisplayEmployee : Window
    {
        public DisplayEmployee()
        {
            InitializeComponent();
        }

        public static DataTable LoadDataGrid()
        {
            SqlDataReader rdrEmp = null;
            SqlConnection connObj = new SqlConnection();
            DataTable dtEmp = new DataTable();
            // Initialize the Connection object and set the ConnectionString Property
            try
            {

                connObj.ConnectionString = @"Data Source=ndamssql\sqlilearn;Initial Catalog=Sep19CHN;User ID=sqluser;Password=sqluser";

                #region ignore
                /* Initialize the Command object
                // Initialization1
                SqlCommand cmdObj = new SqlCommand();
                cmdObj.CommandText = "select * from [Geetha].[Employee]";
                cmdObj.Connection = connObj;

                //Initialization2
                SqlCommand cmdObj2 = new SqlCommand("select * from [Geetha].[Employee]");
                cmdObj2.Connection = connObj;*/
                #endregion
                //Initialization3

                SqlCommand cmdObj = new SqlCommand("select * from [Rashmi].[Employee]", connObj);

                // Execute the Command
                connObj.Open();
                rdrEmp = cmdObj.ExecuteReader();
                if (rdrEmp.HasRows)
                {

                    dtEmp.Load(rdrEmp);
                    // binding UI with data
                }

            }
            catch (SqlException se)
            {
                MessageBox.Show("Exception Occurred" + se.Message, "Employee Form");
            }

            finally
            {
                rdrEmp.Close();
                if (connObj.State == ConnectionState.Open)
                    connObj.Close();
            }
            return dtEmp;
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            dg_dsShow.ItemsSource = LoadDataGrid().DefaultView;
        }
    }
}
