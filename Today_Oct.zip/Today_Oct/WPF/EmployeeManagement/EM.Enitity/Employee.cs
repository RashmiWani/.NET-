﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EM.Enitity
{
    /// <summary>
    /// Dvelepor ID : 161616
    /// Deeloper Name : Rashmi A. Wani
    /// Description :This is an entity class for Employee 
    /// Date of Modification : 15/10/2018
    /// </summary>
    public class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public string EmpLocation { get; set; }
        public long EmpPhone { get; set; }
        public int DeptID { get; set; }
    }
}
