﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace EM.DAL
{
    public class EmployeeOperations
    {
        // static string empConnStr = 
        // Retrieve to connection string from config file using name property

        // conn.ConnectionString = ConfigurationManager.ConnectionStrings["conString"].ToString();

        public DataTable LoadDepartment()
        {
            DataTable dtDept
            try
            {
                dtDept = new DataTable();
                
            }

        }
      
    }
    
}
