﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ApplicationWithSiteMap
{
    public partial class Delete : System.Web.UI.Page
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString);
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("Delete from Rashmi.EmployeeRashmi WHERE EmpID=@eid", con);
            cmd.Parameters.AddWithValue("@eid", txtID.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Employee Data  deteted for Employee ID " + txtID.Text + "');</SCRIPT>");
                txtName.Enabled = false;
                txtContact.Enabled = false;
                txtElocation.Enabled = false;
                btnDelete.Enabled = false;

            }
            else
                Response.Write("<SCRIPT type='text/javascript'>alert('Employee Data not deleted for Employee ID " + txtID.Text + "');</SCRIPT>");
        }
   

        protected void btnSearch_Click(object sender, EventArgs e)
        {

            cmd = new SqlCommand("SELECT * FROM Rashmi.EmployeeRashmi WHERE EmpID = @eid", con);
            cmd.Parameters.AddWithValue("@eid", txtID.Text);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                txtName.Text = dr["EmpName"].ToString();
                txtElocation.Text = dr["EmpLocation"].ToString();
                txtContact.Text = dr["EmpContact"].ToString();

                txtName.Enabled = true;
                txtElocation.Enabled = true;
                txtContact.Enabled = true;
                // btnUpdate.Enabled = true;
            }
            else
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data not found for Stud Code " + txtID.Text + "');</SCRIPT>");
            }
        }
    }
}