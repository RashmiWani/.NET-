﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ApplicationWithSiteMap
{
 
    public partial class Insert : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString);
        SqlCommand cmd;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("insert into Rashmi.EmployeeRashmi values (@ename,@eloc,@econ)", con);
                cmd.Parameters.AddWithValue("@ename", txtName.Text);
            cmd.Parameters.AddWithValue("@eloc", txtElocation.Text);
            cmd.Parameters.AddWithValue("@econ", txtContact.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Employee Data  Inserted');</SCRIPT>");
                txtName.Enabled = false;
                txtContact.Enabled = false;
                txtElocation.Enabled = false;
                btnInsert.Enabled = false;

            }
            else
                Response.Write("<SCRIPT type='text/javascript'>alert('Employee Data not inserted');</SCRIPT>");
        }
    }
    }
