﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;

namespace ePES.PL
{
    public partial class PageLogin : Window
    {
        public PageLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoginCredentials log = new LoginCredentials();
                PolicyValidations polval = new PolicyValidations();
                log.loginID = txtloginid.Text;
                log.userpassword = txtPassword.Password;
                log.userType = cmbUsertype.Text;
                if (polval.ValidateLoginCredentials(log) == true)
                {
                    if (polval.ValidateLogin(log) == true)
                    {
                        if (cmbUsertype.Text == "ADMIN")
                        {
                            AdminHome adminhome = new AdminHome();
                            adminhome.Show();
                            this.Close();
                        }
                        if (cmbUsertype.Text == "CUSTOMER")
                        {
                            CustomerHome customerhome = new CustomerHome();
                            customerhome.txtIDCH.Text = txtPassword.Password;
                            customerhome.Show();
                            this.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid Credentials");
                    }
                }
            }
            catch (PolicyExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtloginid.Clear();
            txtPassword.Clear();
            cmbUsertype.SelectedValue = string.Empty;
        }
    }
}
