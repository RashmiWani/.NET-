﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Employee ID : 161616
/// Employee Name : Rashmi Wani
/// Description : This class will Display and Add new training schedule for ABC Consultancy
/// Modified Date : 01/10/2018
/// </summary>

namespace ABC_Consultancy
{
    public partial class TrainingSchedule : System.Web.UI.Page
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //To display auto generated schedule ID
                SqlCommand cmdObj = new SqlCommand("select IDENT_CURRENT('Rashmi.trainingschedule') + IDENT_INCR('Rashmi.trainingschedule')", con);
                con.Open();
                object objResult = cmdObj.ExecuteScalar();
                int trainingid = Convert.ToInt32(objResult);
                txtSID.Text = trainingid.ToString();
                con.Close();
                //------------------------------------------------------------------------------
                //To display existing training schedule on page load
                SqlCommand cmd = new SqlCommand("Rashmi.usp_ShowTrainingSchedule", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();

                if (dr.HasRows)
                {
                    dt.Load(dr);

                }
                con.Close();

                if (dt.Rows.Count > 0)
                {
                    gvTrainingSch.DataSource = dt;
                    gvTrainingSch.DataBind();
                }
                else
                    Response.Write("<script type='text/javascript'>alert('Training Data Not Available');</script>");

            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        protected void btnScheduleTraining_Click(object sender, EventArgs e)
        {
            try
            {
                // to add new training schedule
                SqlCommand cmd = new SqlCommand("Rashmi.usp_AddTrainingSchedule", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@trainername", txtFNAme.Text);
                cmd.Parameters.AddWithValue("@coursename", ddlCName.Text);

                cmd.Parameters.AddWithValue("@startdate", Convert.ToDateTime(txtStart.Text));
                cmd.Parameters.AddWithValue("@enddate", Convert.ToDateTime(txtEnd.Text));

                cmd.Parameters.AddWithValue("@company", txtComName.Text);
                cmd.Parameters.AddWithValue("@location", txtLoc.Text);

                con.Open();
                int rowsAffected = Convert.ToInt32(cmd.ExecuteNonQuery());
                con.Close();
                if (rowsAffected > 0)
                {
                    Response.Write("<script type='text/javascript'>alert('Training Data Inserted');</script>");
                }
                else
                {
                    Response.Write("<script type='text/javascript'>alert('Training Data Not Inserted');</script>");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}